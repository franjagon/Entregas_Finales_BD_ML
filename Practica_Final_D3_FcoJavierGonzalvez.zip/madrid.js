/*
    BOOTCAMP IV BIG DATA & MACHINE LEARNING  --KEEPCODING--

    PRACTICA FINAL DE LA ASIGNATURA DE VISUALIZACION MODERNA DE DATOS AD-HOC CON D3 Y JAVASCRIPT

    PROFESOR:  MIGUEL ANGEL DIAZ SANCHEZ
    ALUMNO:    FRANCISCO JAVIER GONZALVEZ CHICO
*/

/*
  Como comentario inicial indicar que el código funciona perfectamente en Chrome [Versión 78.0.3904.97 (Build oficial) (64 bits)] y en Mozilla Firefox Browser [70.0.1 (64-bit)].
  No carga el contenido Javascript D3 ni en Internet Explorer, ni en Edge. No he probado más navegadores.
*/

const tama = 800;
const tama2 = tama * 2;
const ancho1 = 130;
const borde = 70;
const borde2 = 100;
const tamaeje = 50;

const color1 = d3.scaleOrdinal(d3.schemeSet3);            // utilizamos una paleta de 12 colores para tener menos repeticiones al colorear los barrios del mapa de Madrid. 
const color2 = d3.scaleOrdinal(d3.schemeSet1);            // utilizamos una paleta de 9 colores vivos para colorear las barras de la gráfica 1.
const color3 = d3.scaleOrdinal(d3.schemeTableau10);       // utilizamos una paleta de 10 colores vivos para colorear los puntos de la gráfica 2.

/*
  En el primer bloque del código cargamos los datos de origen (json) desde url con el método apropiado de D3 y en la arrow-function del método 'then' lo denominamos "madrid".
  En el cuerpo de la arrow-function:
    1.- Cargamos en la variable "proprenom" el resultado de la llamada a la función 'propPrecNom' a la que le pasamos "madrid".
        Esta función devuelve un array de arrays de tres elementos: el número de propiedades, el precio medio de alquiler y el nombre de cada barrio.
        Esta colección se utilizará para pintar la nube de puntos de la #grafica2.
    2.- Cargamos en la variable "propre" el resultado de iterar los elementos de "proprenom" quitando de cada array interior el nombre del barrio.
        Esta colección se utilizará para pintar la recta de regresión lineal de la #grafica2.

    -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    ME HE VISTO EN LA OBLIGACION DE INCLUIR ESTE CODIGO PARA EL TRATAMIENTO DE LOS ARRAYS PORQUE PROBE A CLONAR EL ARRAY 'proprenom' SOBRE EL ARRAY 'propre' MEDIANTE EL COMANDO
          let propre = proprenom.slice();
    CON EL OBJETIVO DE QUE FUERAN DOS ARRAYS INDEPENDIENTES Y PODER HACER .pop SOBRE LOS ELEMENTOS DEL SEGUNDO Y QUITAR EL NOMBRE DEL BARRIO SIN AFECTAR AL PRIMERO Y NO FUNCIONABA    
    -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    3.- Invocamos las funciones de pintado (que se comentarán en detalle justo antes de cada uno de sus bloques de código).
        Pintamos la capa #mapa_barrios, con la función 'pintaMapa', pasándole el json completo.
        Pintamos la capa #grafica1, con la función 'pintaG1', pasándole el bloque de datos (procesado por la funcion 'habProp') del primer barrio del json y el nombre de ese barrio.
        Pintamos la capa #grafica2, con la función 'pintaG2', pasándole las dos colecciones obtenidas y el json completo.
*/

d3.json('https://gist.githubusercontent.com/miguepiscy/2d431ec3bc101ef62ff8ddd0e476177f/raw/d9f3a11cfa08154c36623c1bf01537bb7b022491/practica.json')
  .then(madrid => {
    const proprenom = propPrecNom(madrid);
    let propre = [];

    for(let i in proprenom){
      arr = [];

      for(let j in proprenom[i]){
        if(j != 2) arr.push(proprenom[i][j]);
      }

      propre.push(arr);
    }

    pintaMapa(madrid);
    pintaG1(habProp(madrid.features[0]), madrid.features[0].properties.name);
    pintaG2(proprenom, propre, madrid);
  });

/*
  Esta primera función principal pinta el mapa de los barrios de Madrid en la capa <div> #mapa_barrios.
  La función debe recibir como parámetro el json completo (en el que identificará las geometrías con las que generará los elementos 'path' a pintar).

    1.- Colgamos un (lienzo) svg de 800x800 de la capa.
    2.- Elegimos una geoproyección 'geoMercator'.
        Con el centro geográfico en las coordenadas de La Puerta del Sol.
        Una escala de 96000 (elegida a base de ensayo/error, para que el mapa aparezca proporcionado al lienzo).
        Centrado en la mitad de la extensión horizontal y a casi 2/3 de la extensión vertical del lienzo (también a base de ensayo/error para que el mapa aparezca lo mas centrado posible).
    3.- Generamos el elemento 'path' de la geoproyección.
    4.- Colgamos del svg -n- elementos 'path', uno por cada barrio (iterando las features del json) a partir de sus geometrías.
    5.- Colgamos del svg (seleccionado por el nombre de su clase '.mapa') un texto "leyenda" que aparecerá/desaparecerá cuando el ratón entre/salga del área de cualquiera de los barrios.
*/

function pintaMapa(data){
  const svg = d3.select('#mapa_barrios')
    .append('svg')
    .attr('width', tama)
    .attr('height', tama)
    .attr('class', 'mapa');

  const projection = d3.geoMercator()
    .scale(96000)
    .center([-3.703521, 40.417007])
    .translate([tama/2, 1.9*tama/3]);

  const path = d3.geoPath()
    .projection(projection);
  
  svg.selectAll('path')
    .data(data.features)
    .enter()
    .append('path')
    .attr('d', path)
    .attr('class', 'barrio')
    .attr('id', d => d.properties.name)
    .attr('stroke-width', 1)
    .attr('stroke', 'white')
    .attr('fill', d => {                                // damos color a cada barrio en función del rango de su precio medio de alquiler (con una escala cromática de 12 colores + 2).
      if(d.properties.avgprice === undefined){
        d.properties.avgprice = 0;
        return color3();
        }
      else if(d.properties.avgprice < 20) return color1(0);
           else if(d.properties.avgprice < 30) return color1(1);
                else if(d.properties.avgprice < 40) return color1(2);
                     else if(d.properties.avgprice < 50) return color1(3);
                          else if(d.properties.avgprice < 60) return color1(4);
                               else if(d.properties.avgprice < 70) return color1(5);
                                    else if(d.properties.avgprice < 80) return color1(6);
                                         else if(d.properties.avgprice < 90) return color1(7);
                                              else if(d.properties.avgprice < 100) return color1(8);
                                                   else if(d.properties.avgprice < 110) return color1(9);
                                                        else if(d.properties.avgprice < 130) return color1(10);
                                                             else if(d.properties.avgprice < 200) return color1(11);
                                                                  else return color2();
    })   
    .on("mouseover", muestraLeyenda)                    // controlamos el evento de que el ratón entre en el área de un barrio (si lo hace invocamos la función 'muestraLeyenda').
    .on("mouseout", quitaLeyenda)                       // controlamos el evento de que el ratón salga del área de un barrio (si lo hace invocamos la función 'quitaLeyenda').
    .on("click", clickArea);                            // controlamos el evento de que el raton haga click sobre el área de un barrio (si lo hace invocamos la función 'clickArea').

  const leyenda = d3.select('.mapa')
    .append('text')
    .attr('x', borde) 
    .attr('y', tama - 90)
    .attr('fill', 'darkred')
    .attr('stroke', 'darkred')
    .attr('font-family', 'Verdana')
    .attr('font-size', 20)
    .attr('class', 'popup');

  /*
    Esta primera función interna hace que aparezca un texto sobre el lienzo si el ratón entra en el área de uno de los barrios del mapa.
    La función debe recibir como parámetro el bloque de datos del barrio correspondiente al área en la que el ratón entra.
    
    La "leyenda" de texto constará de dos líneas: la primera con el precio medio de alquiler del barrio y la segunda con el nombre del barrio.
  */

  function muestraLeyenda(data) {
    leyenda.style('display', 'inline')
      .text('Precio Medio: ' + data.properties.avgprice + ' €')
      .append('tspan')
      .attr('x', borde) 
      .attr('y', tama - 60)
      .text('Barrio: ' + data.properties.name);
  }

  /*
    Esta segunda función interna hace que desaparezca la "leyenda" si el ratón sale del área del barrio en el que estuviera.
    La función no necesita recibir parámetros.
  */

  function quitaLeyenda() {
    leyenda.style('display', 'none');
  }

  /*
    Esta tercera función interna hace que la #gráfica1 cambie en función del barrio del mapa sobre el que el ratón haga click.
    La función debe recibir como parámetro el bloque de datos del barrio sobre el que el ratón haga click.
    
      1.- Borra el contenido de la capa #grafica1.
      2.- Pinta la capa #grafica1 pasándole el bloque de datos del barrio del área del mapa en la que el ratón haga click (procesado por la funcion 'habProp'), y el nombre de ese barrio.
  */

  function clickArea(data){
    d3.select('#grafica1')
      .selectAll('*')
      .data(data)
      .exit()
      .remove();

    pintaG1(habProp(data), data.properties.name);
  }
}

/*
  Esta segunda función principal pinta la gráfica, del número de propiedades de un barrio agrupadas por el número de habitaciones de las que disponen, en la capa <div> #grafica1.
  Esta gráfica será un histograma de barras verticales (con los ejes implícitos) sobre y bajo las cuales indicaremos los valores que representen.
  La función debe recibir dos parámetros:
      ~1  data   --> debe llegar un array de arrays de dos elementos: el primero será un número de habitaciones y el segundo el número de propiedades en el barrio con esas habitaciones.
      ~2  barrio --> debe llegar el nombre del barrio.

    1.- Lo primero que hacemos es definir una escala lineal para controlar el tamaño vertical de las barras, reservando un margen de 25 pixels del lienzo por encima y por debajo de su tamaño máximo.
    2.- Colgamos un (lienzo) svg de 800x800 de la capa.
    3.- Colgamos del svg -n- elementos 'rect', uno para cada barra del histograma (iterando el array de datos recibido).
    4.- Colgamos del svg -n- elementos 'text', para indicar cada valor del número de propiedades encima de cada barra (iterando el array de datos recibido).
    5.- Colgamos del svg -n- elementos 'text', para las etiquetas con el número de habitaciones bajo cada barra (iterando el array de datos recibido).
    6.- Colgamos del svg (seleccionado por el nombre de su clase '.G1') un texto de dos líneas: la primera con el total de propiedades del barrio y la segunda con su nombre.
*/

function pintaG1(data, barrio){   
  const escalaG1 = d3.scaleLinear()
    .domain([0, 1000])
    .range([0, 750]);

  const svg = d3.select('#grafica1')
    .append('svg')
    .attr('width', tama)
    .attr('height', tama)
    .attr('class', 'G1');

  svg.selectAll('rect')
    .data(data)
    .enter()
    .append('rect')
    .attr('x', posX1)                               // posicionamos horizontalmente cada barra llamando a la función 'posX1'.
    .attr('y', d => tama - 30 - escalaG1(d[1]))     // posicionamos verticalmente cada barra a 30 pixels (escalados) del suelo del lienzo.
    .attr('width', ancho1)                          // fijamos la anchura de todas las barras en 130 pixels.
    .attr('height', d => escalaG1(d[1]))            // calculamos la altura (escalada) de cada barra en función del valor del número de propiedades.
    .attr('fill', d => color2(d[1]));               // damos color a cada barra en función del valor del número de propiedades (con una escala cromática de 9 colores).

  svg.selectAll('text1')
    .data(data)
    .enter()
    .append('text')
    .text(d => {
      if(d[1] === 1) return d[1] + ' propiedad';    // controlamos el singular o el plural del texto de la etiqueta.
      else return d[1] + ' propiedades';
  })
    .attr('x', posX2)                               // posicionamos horizontalmente cada etiqueta llamando a la función 'posX2'.
    .attr('y', d => tama - 35 - escalaG1(d[1]))     // posicionamos verticalmente cada etiqueta 35 pixels (escalados) por encima de su barra.
    .attr('stroke', 'darkgray')
    .attr('font-family', 'Verdana')
    .attr('font-size', 14);

  svg.selectAll('text2')
    .data(data)
    .enter()
    .append('text')
    .text(d => {
      if(d[0] === 1) return d[0] + ' hab.';         // controlamos el singular o el plural del texto de la etiqueta.
      else return d[0] + ' habs.';
    })
    .attr('x', posX3)                               // posicionamos horizontalmente cada etiqueta llamando a la función 'posX3'.
    .attr('y', tama - 15)                           // posicionamos verticalmente cada etiqueta 15 pixels (sin escalar) por encima del suelo del lienzo.
    .attr('stroke', 'black')
    .attr('font-family', 'Verdana')
    .attr('font-size', 14);

  let sumaProp = 0;

  for(let i in data){                               // iteramos el array de datos recibido para calcular la suma total de las propiedades del barrio.
    sumaProp = sumaProp + data[i][1]
  }

  d3.select('.G1')
    .append('text')
    .attr('x', 370)
    .attr('y', 250)
    .attr('stroke', 'darkred')
    .attr('font-family', 'Verdana')
    .attr('font-size', 20)
    .text('Barrio: ' + barrio)
    .append('tspan')
    .attr('x', 370)
    .attr('y', 280)
    .text('Propiedades: ' + sumaProp);

  /*
    Esta primera función interna devuelve el valor horizontal en el que posicionar cada barra del histograma en función del indice de iteración.
  */

  function posX1(d, i){
    return borde + i * (ancho1 + 5);
  }

  /*
    Esta segunda función interna devuelve el valor horizontal en el que posicionar cada etiqueta con el número de propiedades del histograma en función del indice de iteración.
  */

  function posX2(d, i){
    return (borde + 7) + i * (ancho1 + 5);
  }

  /*
    Esta tercera función interna devuelve el valor horizontal en el que posicionar cada etiqueta con el número de habitaciones del histograma en función del indice de iteración.
  */
  
  function posX3(d, i){
    return (borde + 40) + i * (ancho1 + 5);
  }
}

/*
  Esta tercera función principal pinta la gráfica, del número de propiedades por barrio frente a su precio medio de alquiler, en la capa <div> #grafica2.
  Esta gráfica será un diagrama de dispersión sobre el que se dibujará su recta de regresión lineal.
  La función debe recibir tres parámetros:
      ~1  data   --> debe llegar un array de arrays de tres elementos: el primero será el número de propiedades, el segundo el precio medio y el tercero el nombre, de cada barrio.
      ~2  data2  --> debe llegar un array de arrays de dos elementos: el primero será el número de propiedades y el segundo el precio medio, de cada barrio.
      ~3  madrid --> debe llegar el json completo.

    1.- Lo primero que hacemos es conseguir la función que proporcionará el pintado de la recta de regresión lineal pasándole el array "data2".
    2.- Definimos dos escalas lineales para controlar el tamaño de la gráfica, reservando un margen de 100 pixels del lienzo por encima, por debajo y por cada lado. Con el objeto de que
        la nube de puntos se pinte de forma adecuada estéticamente, aumentamos en 5 pixels los valores máximos de nuestros datos para que los ejes aparenten contenerlos sin problema. 
    3.- Colgamos un (lienzo) svg de 1600x800 de la capa.
    4.- Colgamos del svg -n- elementos 'circle', uno para cada punto de la nube (iterando el array de datos recibido).
    5.- Colgamos del svg (seleccionado por el nombre de su clase '.G2') un elemento 'line', para la recta de regresión lineal.
    6.- Colgamos del svg (seleccionado por el nombre de su clase '.G2') un texto de dos líneas para escribir sobre la gráfica la fórmula de la recta de regresión lineal representada.
    7.- Colgamos del svg (seleccionado por el nombre de su clase '.G2') un elemento 'rect' para servir de fondo a la fórmula de la recta de regresión lineal representada.
    8.- Colgamos del svg dos grupos para ambos ejes de coordenadas y a cada grupo le añadimos un texto para presentar el título de cada eje.
    9.- Colgamos del svg (seleccionado por el nombre de su clase '.G2') un texto de tres líneas: la primera con el nombre del barrio, la segunda con su total de propiedades y la tercera
        con su precio medio.
*/

function pintaG2(data, data2, madrid){
  const l = ss.linearRegression(data2);
  const lr = ss.linearRegressionLine(l);

  const xmax = d3.max(data, d => d[0]);
  const ymax = d3.max(data, d => d[1]);

  const escalaX = d3.scaleLinear()
    .domain([0, xmax + 5])
    .range([borde2, tama2 - borde2]);
  
  const escalaY = d3.scaleLinear()
    .domain([ymax + 5, 0])
    .range([borde2, tama - borde2]);
  
  const svg = d3.select('#grafica2')
    .append('svg')
    .attr('width', tama2)
    .attr('height', tama)
    .attr('class', 'G2');

  svg.selectAll('circle')
    .data(data)
    .enter()
    .append('circle')
    .attr('class', 'punto')
    .attr('cx', d => escalaX(d[0]))     // posicionamos horizontalmente cada punto en función del valor del número de propiedades (escalado horizontal) de su barrio.
    .attr('cy', d => escalaY(d[1]))     // posicionamos verticalmente cada punto en función del valor del precio medio (escalado vertical) de su barrio.
    .attr('r', d => 5)                  // fijamos un radio de 5 pixels para los puntos
    .attr('fill', d => color3(d[1]))    // damos color a cada punto en función del valor del precio medio de su barrio (con una escala cromática de 12 colores). 
    .on("mouseover", muestraDatos)      // controlamos el evento de que el ratón entre en el área de un punto (si lo hace invocamos la función 'muestraDatos').
    .on("mouseout", quitaDatos)         // controlamos el evento de que el ratón salga del área de un punto (si lo hace invocamos la función 'quitaDatos').
    .on("click", clickPunto);           // controlamos el evento de que el raton haga click sobre el área de un barrio (si lo hace invocamos la función 'clickPunto').

  d3.select('.G2')
    .append('line')
    .attr('x1', escalaX(0))             // elegimos como coordenada horizontal para el principio de la recta el origen X (escalado horizontal).
    .attr('y1', escalaY(lr(0)))         // obtenemos como coordenada vertical para el principio de la recta el resultado (escalado vertical) de invocar la función 'lr' con la coordenada inicial X.
    .attr('x2', escalaX(180))           // elegimos como coordenada horizontal para el final de la recta el tope de nuestro eje X (escalado horizontal).
    .attr('y2', escalaY(lr(180)))       // obtenemos como coordenada vertical para el final de la recta el resultado (escalado vertical) de invocar la función 'lr' con la coordenada final X.
    .attr('stroke', '#5300A6')
    .attr('stroke-width', 2);

  d3.select('.G2')
    .append('rect')
    .attr('x', 1255)
    .attr('y', tama - 475)
    .attr('width', 170)
    .attr('height', 37)
    .attr('fill', '#F4D4FF');

  d3.select('.G2')
    .append('text')
    .attr('x', 1270)
    .attr('y', tama - 460)
    .attr('fill', '#5300A6')
    .attr('font-family', 'Verdana')
    .attr('font-size', 11)
    .attr('class', 'formula')
    .text('Recta de Regresión Lineal')
    .append('tspan')
    .attr('x', 1275)
    .attr('y', tama - 445)
    .text('y = 0.2655x + 38.8319');

  const xAxis = d3.axisBottom(escalaX).ticks(30);
  const yAxis = d3.axisLeft(escalaY);

  svg.append('g')
    .attr('class', 'axisX')
    .attr('transform', `translate(0,${tama - borde2})`)
    .call(xAxis);
  
  d3.select('.axisX')
    .append('text')
    .attr('x', 800)
    .attr('y', 45)
    .attr('stroke', 'black')
    .attr('fill', 'black')
    .attr('font-family', 'Verdana')
    .attr('font-size', 16)
    .text('Número de Propiedades por Barrio');
  
  svg.append('g')
    .attr('class', 'axisY')
    .attr('transform', `translate(${borde2}, 0)`)
    .call(yAxis);
  
  d3.select('.axisY')
    .append('text')
    .attr('x', -300)
    .attr('y', -45)
    .attr('stroke', 'black')
    .attr('fill', 'black')
    .attr('font-family', 'Verdana')
    .attr('font-size', 16)
    .attr('transform', `rotate(-90)`)     // el título del eje vertical lo rotamos -90 grados para sacarlo en vertical.
    .text('Precio Medio por Barrio');

  const datosPunto = d3.select('.G2')
    .append('text')
    .attr('x', 900)
    .attr('y', tama - 600)
    .attr('fill', 'darkred')
    .attr('stroke', 'darkred')
    .attr('font-family', 'Verdana')
    .attr('font-size', 20)
    .attr('class', 'popup2');

  /*
    Esta primera función interna hace que aparezca un texto sobre el lienzo si el ratón entra en el área de uno de los puntos de la nube.
    La función debe recibir como parámetro el bloque de datos del barrio correspondiente al punto en el que el ratón entra.
    
    El texto constará de de tres líneas: la primera con el nombre del barrio, la segunda con su total de propiedades y la tercera con su precio medio.
  */  

  function muestraDatos(data) {
    datosPunto.style('display', 'inline')
      .text('Barrio: ' + data[2])
      .append('tspan')
      .attr('x', 900)
      .attr('y', tama - 570)
      .text('Propiedades: ' + data[0])
      .append('tspan')
      .attr('x', 900)
      .attr('y', tama - 540)
      .text('Precio Medio: ' + data[1] + ' €');
  }

  /*
    Esta segunda función interna hace que desaparezca el texto si el ratón sale del punto en el que estuviera.
    La función no necesita recibir parámetros.
  */
  
  function quitaDatos() {
    datosPunto.style('display', 'none');
  }

  /*
    Esta tercera función interna hace que la #gráfica1 cambie en función del barrio correspondiente al punto sobre el que el ratón haga click.
    La función debe recibir como parámetro el bloque de datos del barrio sobre el que el ratón haga click.
    
      1.- Consigue, recorriendo el json, el bloque de datos del barrio correspondiente al punto en el que el ratón haga click.
      2.- Borra el contenido de la capa #grafica1.
      2.- Pinta la capa #grafica1 pasándole el bloque de datos del barrio del área del mapa en la que el ratón haga click (procesado por la funcion 'habProp'), y el nombre de ese barrio.
  */

  function clickPunto(data){
    let barrio;

    for(let i in madrid.features){
      if(madrid.features[i].properties.name === data[2]){
        barrio = madrid.features[i];
      }
    }
  
    d3.select('#grafica1')
      .selectAll('*')
      .data(barrio)
      .exit()
      .remove();

    pintaG1(habProp(barrio), data[2]);
  }
}

/*
  Esta primera función auxiliar genera el array de arrays de dos elementos de un barrio que necesita la función que pinta la #grafica1.
  La función debe recibir como parámetro el bloque de datos (json) de un barrio.

  En el bloque de datos (json) de un barrio hay un grupo "avgbedrooms" en el que se iteran duplas -número de habitaciones/total de propiedades-.
  La función se encarga de convertir ese bloque json en un array que contiene esas duplas (arrays de dos elementos).  
*/

function habProp(data){
  const arrHabPro = [];
  
  for(let i in data.properties.avgbedrooms){
    const arr = [];
    arr.push(data.properties.avgbedrooms[i].bedrooms);
    arr.push(data.properties.avgbedrooms[i].total);
    arrHabPro.push(arr);
  }
  
  return arrHabPro;
}

/*
  Esta segunda función auxiliar genera el array de arrays de tres elementos de un barrio que necesita la función que pinta la #grafica2.
  La función debe recibir como parámetro el json completo.

  La función se encarga de recorrer el json y montar el array buscado con tripletas compuestas de -número total de propiedades/precio medio del alquiler/nombre- de cada barrio.
  La función tambien realiza el filtrado de elementos (barrios) << outlayers >>. Para que la nube de puntos se vea proporcionada, eliminamos los barrios cuyo precio medio llega
  indefinido (undefined) o supera los 150€; asimismo eliminamos también los que tienen mas de 200 propiedades en total. De esta forma la nube se presenta de forma mas adecuada.
*/

function propPrecNom(data){
  const arrproprenom = [];
  
  for(let i in data.features){
    const arr = [];
    let propiedades = 0;

    if(data.features[i].properties.avgprice != undefined && data.features[i].properties.avgprice < 150){
      
      for(let j in data.features[i].properties.avgbedrooms){
      propiedades = propiedades + data.features[i].properties.avgbedrooms[j].total;
      }
    
      if(propiedades < 200){
        arr.push(propiedades);
        arr.push(data.features[i].properties.avgprice);
        arr.push(data.features[i].properties.name);
        arrproprenom.push(arr);
      }
    }
  }
  
  return arrproprenom;
}

/*
  COMENTARIOS FINALES

  Como nota final de este trabajo me gustaría dar las gracias al profesor Miguel Díaz, por su atención corrigiendo nuestros errores y despejando nuestras dudas (en las clases y en Slack).
  
  Tras el final de los tres días de clase de la asignatura tenía una sensación bastante desangelada... pensaba que había aprendido a pintar/manejar las figuras simples y poco más... y la
  realización de la práctica se me antojaba muy difícil, casi imposible. 
  
  Durante el siguiente fin de semana y esta semana, en la que (porque no decirlo) le he dedicado muchas horas y he trabajado duro poniéndome al día con los conceptos básicos del HTML y JS,
  el horizonte se fue abriendo poco a poco y fui entendiendo e interiorizando lo que el profesor nos fue mostrando y explicando durante las clases.

  Al final, creo sinceramente que he realizado un buen trabajo final (aunque esto, desde luego lo decidirá el profesor) y me quedo con un muy buen sabor de boca y muy contento de que al
  termino de esta práctica realmente me ha gustado mucho trabajar el D3 y poder ver la potencia que realmente esconde.
  
  Sin más, mi más sincero agradecimiento por todas las cosas que he aprendido.

  F. Javier Gonzálvez
*/