package cloacalandia

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.functions._

object ProcesoMensajes {

  def main(args: Array[String]): Unit = {

    //  Mitigo los Logs si no hay errores

    Logger.getLogger("org").setLevel(Level.ERROR)

    //  Instancio la SparkSession

    val spark = SparkSession
      .builder()
      .appName("Definicion_Datasets")
      .master("local[*]")
      .getOrCreate()

    //----------------------------------------------------------------------------------------------------------------//
    //  Objetivo 1                                                                                                    //
    //  Crear las estructuras de los diferentes datasets del sistema                                                  //
    //                                                                                                                //
    //  Utilizo Structype para conformar las diferentes estructuras de los datasets                                   //
    //----------------------------------------------------------------------------------------------------------------//

    //  Creo el esquema de campos para el dataset 'mensajesCapturados'
    //  Además de los campos sugeridos en el enunciado:
    //      - msgId, como identificador unico del mensaje en el fichero enviado
    //      - msgContenido, con el texto del mensaje propiamente dicho
    //      - msgUserId, para identificar el usuario que envía el mensaje (msgSchema.msgUserId == userSchema.userId)
    //  Creo necesario añadir dos campos más a la estructura:
    //      - msgTimestamp, para identificar la fecha/hora de captura del mensaje
    //      - msgZona, para identificar el dispositivo IoT que lo capturó (msgSchema.msgZona == iotSchema.iotZona)

    val msgSchema = new StructType()
      .add("msgId", "string")
      .add("msgContenido", "string")
      .add("msgUserId", "string")
      .add("msgTimestamp", "string")
      .add("msgZona", "string")

    //  Creo el esquema de campos para el dataset 'usuariosRegistrados' con los campos sugeridos en el enunciado
    //  El campo userId sirve de nexo para cruzar este dataset con el de los mensajes capturados

    val userSchema = new StructType()
      .add("userId", "string")
      .add("userNombre", "string")
      .add("userApellido", "string")
      .add("userEdad", "integer")
      .add("userSexo", "string")

    //  Creo el esquema de campos para el dataset 'dispositivosIoT' con los campos sugeridos en el enunciado
    //  El campo iotZona sirve de nexo para cruzar este dataset con el de los mensajes capturados

    val iotSchema = new StructType()
      .add("iotId", "string")
      .add("iotOnOff", "boolean")
      .add("iotZona", "string")

    //  Creo el esquema de campos para el dataset 'blacklist'

    val blacklistSchema = new StructType()
      .add("palabraBL", "string")

    //  Creo el esquema de campos para el dataset 'exclusiones'
    //  Este dataset contendrá las palabras excluidas (no contables): artículos, preposiciones y conjunciones

    val exclusionesSchema = new StructType()
      .add("palabraEx", "string")

    //----------------------------------------------------------------------------------------------------------------//
    //  Objetivo 2                                                                                                    //
    //  Cargar los datasets con información dummy                                                                     //
    //                                                                                                                //
    //  Utilizo read.format para cargar los datasets desde ficheros csv                                               //
    //  Los ficheros los he generado con información totalmente ficticia                                              //
    //----------------------------------------------------------------------------------------------------------------//

    //  Cargo el dataset 'mensajesCapturados' con su esquema personalizado
    //  Los mensajes capturados, y recogidos del streaming de Kafka, se han almacenado en la carpeta 'EntradaKafka'

    val mensajesCapturados = spark.read.format("csv")
      .option("header", true)
      .schema(msgSchema)
      .load("EntradaStreaming/mensajes.csv")

    //  Cargo el dataset 'usuariosRegistrados' con su esquema personalizado desde la carpeta 'Directorio'

    val usuariosRegistrados = spark.read.format("csv")
      .option("header", true)
      .schema(userSchema)
      .load("Directorio/usuarios.csv")

    //  Cargo el dataset 'dispositivosIoT' con su esquema personalizado desde la carpeta 'Directorio'

    val dispositivosIoT = spark.read.format("csv")
      .option("header", true)
      .schema(iotSchema)
      .load("Directorio/dispositivos.csv")

    //  Cargo el dataset 'blacklist' con su esquema personalizado desde la carpeta 'Directorio'

    val blacklist = spark.read.format("csv")
      .option("header", true)
      .schema(blacklistSchema)
      .load("Directorio/blacklist.csv")

    //  Cargo el dataset 'exclusiones' con su esquema personalizado desde la carpeta 'Directorio'

    val exclusiones = spark.read.format("csv")
      .option("header", true)
      .schema(exclusionesSchema)
      .load("Directorio/exclusiones.csv")

    //----------------------------------------------------------------------------------------------------------------//
    //  Objetivo 3                                                                                                    //
    //  Procesar el contenido de los mensajes y contar sus palabras                                                   //
    //----------------------------------------------------------------------------------------------------------------//

    //  Creo una función para eliminar los corchetes (signos de apertura y cierre de listas) ya que al convertir
    //  la columna del texto del mensaje, del dataset de mensajes capturados, en un RDD se arrastran estos signos como
    //  caracteres
    //  La función recibe una palabra y la devuelve, pero si lleva pegado (a su principio o a su final) un signo de
    //  apertura o cierre de corchetes lo elimina, para ello la recorre letra a letra descartando estos signos si los
    //  encuentra

    def quitaCorchetes(palabra: String): String = {
      var newPal = ""

      for (letra <- palabra){
        if(letra != '[' & letra != ']'){
          newPal = newPal + letra
        }
      }

      newPal
    }

    //  Creo una función para tratar una fechahora (timestamp)
    //  La función recibe un timestamp (como string), y devuelve un array de enteros con el año, el mes, el día, la
    //  hora y los minutos

    def trataTimestamp(timestamp: String): (Int, String, Int, Int, Int) = {
      var n = 0
      var parte = ""
      var day = 0
      var month = ""
      var year = 0
      var hour = 0
      var minute = 0

      for (caracter <- timestamp){

        if(caracter == '/' & n == 0) {
          day = parte.toInt
          n += 1
          parte = ""
        } else if(caracter == '/' & n == 1) {
          parte match{
            case "01" => month = "enero"
            case "02" => month = "febrero"
            case "03" => month = "marzo"
            case "04" => month = "abril"
            case "05" => month = "mayo"
            case "06" => month = "junio"
            case "07" => month = "julio"
            case "08" => month = "agosto"
            case "09" => month = "septiembre"
            case "10" => month = "octubre"
            case "11" => month = "noviembre"
            case "12" => month = "diciembre"
          }
          n += 1
          parte = ""
        } else if(caracter == ' ') {
          year = parte.toInt
          n += 1
          parte = ""
        } else if(caracter == ':') {
          hour = parte.toInt
          n += 1
          parte = ""
        } else parte = parte + caracter
      }

      minute = parte.toInt

      (day, month, year, hour, minute)
    }

    //  Importo spark.implicits._ para poder convertir datasets en RDDs

    import spark.implicits._

    //  Con el dataset 'mensajesCapturados' procedo a crear un RDD sólo con la columna que contiene el mensaje

    val mensajesRDD = mensajesCapturados.select($"msgContenido").rdd

    //  Convierto la columna del RDD a tipo 'string', separo las palabras, las pongo en minúsculas y, con la función
    //  'quitaCorchetes', quito los signos de corchetes no deseados
    //  Finalmente reconvierto la colección en un dataset para poder cruzarlo contra las palabras excluidas y asi
    //  descartarlas

    val palabrasTotalDS = mensajesRDD
      .map(registro => registro.toString())
      .flatMap(frase => frase.split(" "))
      .map(palabra => palabra.toLowerCase)
      .map(palabra => quitaCorchetes(palabra))
      .toDS()
      .withColumnRenamed("value", "palabra")

    //  Cruzo completo [left_outer] el dataset de las palabras obtenido de el de los mensajes capturados contra el
    //  dataset 'exclusiones'
    //  Las palabras excluidas existentes en nuestro dataset se duplicarán en las dos columnas del dataset resultado y
    //  las válidas tendrán un valor 'null' en la segunda columna

    val palabrasContraExclusionesDS = palabrasTotalDS.join(exclusiones,
      palabrasTotalDS.col("palabra") === exclusiones.col("palabraEx"), "left_outer")

    //  Para extraer del resultado sólo las palabras válidas elijo las que en la segunda columna tienen el valor 'null'

    val palabrasValidasDS = palabrasContraExclusionesDS
      .filter($"palabraEx".isNull)
      .select($"palabra")

    //  Genero un dataset con el conteo de repeticiones de las palabras válidas

    val conteoDS = palabrasValidasDS
      .groupBy("palabra")
      .count()
      .withColumnRenamed("count", "repeticiones")

    //  Muestreo por consola las diez palabras, con contenido semántico, más repetidas en los mensajes, ordenadas por
    //  número de repeticiones de mayor a menor

    println("\nDurante la última hora, las diez palabras más repetidas, en los mensajes\n" +
      "capturados de la red social 'CELEBRAM', son las siguientes:\n")

    conteoDS.sort(desc("repeticiones"), asc("palabra"))
      .show(10)

    //  Genero un dataset con el mayor conteo de repeticiones para poder identificar a posteirori la/s palabra/s que se
    //  ha/yan repetido ese número de veces

    val mayorConteoDS = conteoDS.agg(max($"repeticiones"))

    //  Obtengo el dataset con la/s palabra/s más repetida/s (por si hubiera más de una palabra con el mismo número
    //  máximo de repeticiones) cruzando [inner] los datasets de conteo de repeticiones y de máximo de repeticiones
    //  Y como el número de repeticiones queda duplicado en columnas tras el cruce, descarto la columna correspondiente
    //  al segundo dataset

    val palabrasMasRepetidasDS = conteoDS
      .join(mayorConteoDS, conteoDS.col("repeticiones") === mayorConteoDS.col("max(repeticiones)"))
      .drop($"max(repeticiones)")

    //  Busco si la/s palabra/s más repetida/s están en la lista negra, para ello cruzo [inner] el dataset recién
    //  obtenido contra el dataset que contiene la BlackList
    //  Si alguna palabra del dataset de las más repetidas está en la BlackList quedará duplicada tras el cruce, por
    //  tanto sólo selecciono la columna de la palabra BlackList y la columna con su número de repeticiones

    val palabrasEnLaBlackListDS = palabrasMasRepetidasDS
      .join(blacklist, palabrasMasRepetidasDS.col("palabra") === blacklist.col("palabraBL"))
      .select($"palabraBL", $"repeticiones")

    //  Cuento cuantas palabras han resultado estar en la BlackList

    val cuantasPalabrasEnLaBlacklist = palabrasEnLaBlackListDS.count()

    //  Si hay alguna palabra de la BlackList, procedo a conformar el mensaje de alerta

    if(cuantasPalabrasEnLaBlacklist > 0){

      //  Aterrizo el dataset ordenado alfabéticamente por palabra sobre una colección rdd y elimino los corchetes
      //  convirtiendo cada row en string

      val palabrasEnLaBlackList = palabrasEnLaBlackListDS.sort(asc("palabraBL")).rdd.collect()

      val palabrasBLlimpias = palabrasEnLaBlackList.map(row => quitaCorchetes(row.toString))

      //  Procedo a extraer el timestamp del primero de los mensajes capturados y lo convierto en una cadena
      //  Lo trato con la función para quitar corchetes y después con la función que lo trocea dato a dato

      val timestampMSG = quitaCorchetes(mensajesCapturados.select($"msgTimestamp").first().toString())

      val timestamp = trataTimestamp(timestampMSG)

      //  Una vez tengo los datos que necesito preparados, escribo el texto del mensaje de alerta...
      //  ...(que asumo será enviado por algún otro sistema vía email)

      println("\n\n\n" +
        "------------------------------------------------------------------------\n\n" +
        "  MENSAJE DE ALERTA PARA EL MINISTERIO DE INTELIGENCIA DE CLOACALANDIA\n\n" +
        "------------------------------------------------------------------------\n\n\n\n" +
        "   A la Atención del EXCELENTÍSIMO SEÑOR MINISTRO.\n\n\n" +
        "   Desde el Departamento Secreto de Hackers, siempre a su servicio, ponemos en su conocimiento que:\n\n" +
        s"a día de hoy ${timestamp._1} de ${timestamp._2} de ${timestamp._3}, durante la franja horaria entre " +
        s"las ${timestamp._4}:00 y las ${timestamp._4 + 1}:00 horas,")

      //  Dependiendo de si hay más de una palabra de la BlackList repetida el número máximo de veces (lo cual parece
      //  dificil, pero no improbable), escribo la siguiente frase en singular o en plural

      if(cuantasPalabrasEnLaBlacklist > 1){
        println("las siguientes palabras han sido repetidas, el número de veces que se indica a su lado, en los ")
      } else {
        println("la siguiente palabra ha sido repetida, el número de veces que se indica a su lado, en los ")
      }

      println("mensajes capturados por nuestros dispositivos de espionaje de la red social 'CELEBRAM'.\n\n\n" +
        "          PALABRA,REPETICIONES\n" +
        "         ______________________\n")

      //  Escribo el rdd fila a fila (por si hubiera más de una palabra)

      for (row <- palabrasBLlimpias){
        println(s"          ${row}")
      }

      println("\n\n   Quedamos a su entera disposición, atentos a sus órdenes.\n\n\n   ¡¡ VIVA CLOACALANDIA !!\n\n\n")
    }

    spark.sparkContext.stop()
  }


}
