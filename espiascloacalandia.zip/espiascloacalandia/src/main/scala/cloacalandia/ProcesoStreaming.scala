package cloacalandia

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object ProcesoStreaming {

  def main(args: Array[String]): Unit = {

    // Mitigo los Logs si no hay errores

    Logger.getLogger("org").setLevel(Level.ERROR)

    //  Instancio la SparkSession

    val spark = SparkSession
      .builder()
      .appName("Streaming Cloacalandia")
      .master("local[*]")
      .getOrCreate()

    //  Genero un dataset obteniendo información leyendo streaming del socket NetCat en localhost:9000

    val info = spark.readStream
      .format("socket")
      .option("host", "localhost")
      .option("port", 9000)
      .load()

    import spark.implicits._

    //  Transformo lo recibido por streaming en string para poder escribirlo en un fichero almacén

    val palabras = info.as[String]

    //  La query final únicamente se encargará de ir escribiendo los registros, que se lean de los paquetes streaming,
    //  en un fichero que se analizará en el proceso siguiente

    val query = palabras.writeStream
      .outputMode("append")
      .format("parquet")
      .option("checkpointLocation", "checkpoint")
      .option("path", "EntradaStreaming/mensajesAppend")
      .start()

    query.awaitTermination()
  }

}
